import React from "react";
import Image from "./Image";
import Author from "./Author";
import Question from "./Question";
import IndexButton from "./IndexButton";
import Timer from "./Timer";
import { Link } from "react-router-dom";

export default class Game extends React.Component {
  render() {
    return (
      <div>
        {this.props.quiz.attachment === null ? (
          "ESTE QUIZ NO DISPONE DE IMAGEN =("
        ) : (
          <Image url={this.props.quiz.attachment.url} />
        )}
        {this.props.quiz.author === null ? (
          "Este Quiz No dispone Autor"
        ) : (
          <Author author={this.props.quiz.author} />
        )}

        <Question question={this.props.quiz.question} />

        <form
          onSubmit={(e) => {
            e.preventDefault();
            this.props.currentQuiz === this.props.quizzes.length - 1
              ? this.props.submit()
              : this.props.next();
          }}
        >
          <input
            type="text"
            value={this.props.quiz.userAnswer || ""}
            onChange={(e) => this.props.onQuestionAnswer(e.target.value)}
          />
        </form>
        <div>
          <Link
            to={
              "/game/" +
              (this.props.currentQuiz === 0 ? +1 : this.props.currentQuiz)
            }
          >
            <button onClick={(e) => this.props.previous()}>Anterior</button>
          </Link>
          <Link
            to={
              "/game/" +
              (this.props.currentQuiz === 9 ? +10 : this.props.currentQuiz + 2)
            }
          >
            <button onClick={(e) => this.props.next()}>Siguiente</button>
          </Link>
          <button onClick={(e) => this.props.submit()}>Submit</button>
          <Link to="/game/1">
            <button onClick={(e) => this.props.reset()}>Reset</button>
          </Link>
        </div>

        <IndexButton quizzes={this.props.quizzes} indice={this.props.indice} />

        <Timer submit={this.props.submit} />
      </div>
    );
  }
}
