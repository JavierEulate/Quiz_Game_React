import React from "react";
export default class Inicio extends React.Component {
  render() {
    return (
      <div>
        {window.location.pathname === "/inicio" ? (
          <h1>Bienvenido a Quizzz</h1>
        ) : null}
      </div>
    );
  }
}
