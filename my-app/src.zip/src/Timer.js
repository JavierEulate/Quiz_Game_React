import React, { Component } from "react";

export default class Timer extends Component {
  constructor(props) {
    super(props);

    this.state = {
      counter: 0,
      intervalId: 0,
      timer: 20,
    };
  }

  componentDidMount() {
    const intervalId = setInterval(this.setTimer.bind(this), 1000);
    this.setState({ intervalId });
  }

  componentWillUnmount() {
    clearInterval(this.state.intervalId);
  }

  setTimer() {
    this.setState({
      counter: this.state.counter + 1,
      timer: this.state.timer - 1,
    });

    if (this.state.timer <= 0) {
      this.props.submit();
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return nextState.counter > this.state.counter;
  }

  render() {
    const timer = this.state.timer;
    return <div>{timer}</div>;
  }
}
